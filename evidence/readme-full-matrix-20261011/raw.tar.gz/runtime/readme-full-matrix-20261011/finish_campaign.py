from pathlib import Path
import json, subprocess, sys, time
root=Path.cwd(); run=root/'runtime/readme-full-matrix-20261011'
check=root/'runtime/swift-min128-exact-six-20261011/c6-0-latest'
while not (check/'process.json').exists(): time.sleep(10)
r=json.loads((check/'results.json').read_text())
assert all(c['passed'] for c in r['checks'].values()), r['checks']
assert json.loads((check/'process.json').read_text())['stopped']
if (run/'swift').exists():
 (run/'swift').rename(run/'swift-profile-only-failed')
 (run/'swift-profile-only-failed/EXCLUDED.json').write_text(json.dumps({'reason':'Placement-only repair failed video at six slots. Replaced by full fresh matrix with minimum visual tokens 128 in both arms.'},indent=2))
for weight in ('swift','iq3_s'):
 cmd=[str(root/'.venv/bin/python'),'tools/probe_packed_batch.py','--output',str(run/weight),'--weights',weight,'--counts','1','2','4','6','--arms','shared','latest','latest','shared','--holdout','--media','--native-context','--native-context-counts','1','6','--reserve-mib','2048','--continue-on-check-failure']
 (run/f'{weight}-final-command.json').write_text(json.dumps(cmd,indent=2))
 with (run/f'{weight}-final.log').open('w') as log:
  print('START',weight,flush=True)
  subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('DONE',weight,flush=True)
print('ALL COMPLETE',flush=True)
