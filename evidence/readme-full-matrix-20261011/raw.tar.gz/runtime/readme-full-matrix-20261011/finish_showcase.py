from pathlib import Path
import json,subprocess,time
root=Path.cwd();run=root/'runtime/readme-full-matrix-20261011'
last=run/'iq3_s/c6-3-shared'
while not (last/'process.json').exists():time.sleep(10)
for weight in ('iq2_xs','swift','iq3_s'):
 ps=list((run/weight).glob('*/results.json'));assert len(ps)==16
 for p in ps:
  r=json.loads(p.read_text());assert all(x['passed'] for x in r['checks'].values()),p
python=str(root/'.venv/bin/python')
commands=[('curves',[python,'tools/benchmark_showcase.py','--assets','assets','--gpu','0','--output','runtime/readme-latest-curves-20261011','--suite','curves','--latest']),('pelican',[python,'tools/benchmark_pelican.py','--assets','assets','--gpu','0','--output','runtime/readme-latest-pelican-20261011','--turbo-exe','experimental/sparse-draft-prefill/build/strata-sparse-draft-prefill','--turbo-env','STRATA_MTP_SPARSE_BATCH=1','--turbo-env','STRATA_PF_FUSED=1'])]
for name,cmd in commands:
 print('START',name,flush=True)
 (run/f'{name}-command.json').write_text(json.dumps(cmd,indent=2))
 with (root/f'runtime/readme-latest-{name}-20261011.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
