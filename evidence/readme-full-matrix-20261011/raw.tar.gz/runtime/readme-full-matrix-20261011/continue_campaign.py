import json, os, subprocess, time
from pathlib import Path
root=Path('/home/student_su/qwen/release/strata-single-GPU')
run=root/'runtime/readme-full-matrix-20261011'
while True:
    try: os.kill(1724675,0)
    except ProcessLookupError: break
    time.sleep(10)
if not (run/'iq2_xs/c6-3-shared/results.json').exists():
    raise RuntimeError('First model did not complete; inspect its retained logs')
for weight in ('swift','iq3_s'):
    cmd=[str(root/'.venv/bin/python'),'tools/probe_packed_batch.py','--output',str(run/weight),'--weights',weight,'--counts','1','2','4','6','--arms','shared','latest','latest','shared','--holdout','--media','--native-context','--continue-on-check-failure']
    (run/(weight+'-command.json')).write_text(json.dumps(cmd,indent=2))
    with (run/(weight+'.log')).open('w') as log:
        result=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    (run/(weight+'-exit.json')).write_text(json.dumps({'exit_code':result.returncode}))
    if result.returncode: raise RuntimeError(weight+' run failed; inspect retained evidence')
(run/'COMPLETE.json').write_text(json.dumps({'complete':True}))
